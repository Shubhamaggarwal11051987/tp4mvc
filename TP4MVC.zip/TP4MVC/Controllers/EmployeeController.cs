﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TP4MVC.Models;

namespace TP4MVC.Controllers
{
    public class EmployeeController : Controller
    {
        private ApplicationDbContext dbContext;
        

        public EmployeeController(ApplicationDbContext context)
        {
            dbContext = context;
        }




        public IActionResult Index()
        {
            var emps = new List<string> {"shubham","rahul","sonu" };
            ViewBag.employees = emps;
            return View(emps);
        }



        public IActionResult Create()
        {
           

            return View();

        }



        public IActionResult Details()
        {


            return View();
        }



        public IActionResult Employee()
        {


            return View();
        }








        [HttpPost]
        public IActionResult Create (Employee employee)
        {
            dbContext.employees.Add(employee);
            dbContext.SaveChanges();
            return RedirectToAction("Index");


            
        }
    }
}
