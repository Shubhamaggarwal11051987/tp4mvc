﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TP4MVC.Models
{
    public class Employee
    {
        public int id { get; set; }
        public string  name { get; set; }
        public string email { get; set; }
        public double mobile { get; set; }
        public string gender { get; set; }

        public static implicit operator Employee(ApplicationDbContext v)
        {
            throw new NotImplementedException();
        }
    }
}
